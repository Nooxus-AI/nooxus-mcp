# 🛡️ Nooxus-AI: Sourcing Edge for Claude Desktop (MCP)

**Nooxus-MCP (v0.1.5)** is the official [Model Context Protocol (MCP)](https://modelcontextprotocol.io) gateway to **real-time, verified global supply chain data**.

By installing this into your Claude Desktop, Cherry Studio, or Cursor, you instantly upgrade your AI from a conversational chatbot into a **Forensic Sourcing Analyst**. It cross-references the AII-NOO verified database to expose shell companies, verify real manufacturers, and draft hyper-targeted RFQs in seconds.

-----

## ✨ Why Nooxus? (The "Aha Moment")

  - **Zero-Hallucination Sourcing:** Direct access to Nooxus Edge nodes. If a factory is fake, the AI will know.
  - **Forensic UI Rendering:** Forces Claude to generate a professional UI dashboard (Trust Scores, Red Flags, Capacity) instead of boring text.
  - **Out-of-the-Box Trial:** Includes a built-in community key (1,000,000-query quota). **No sign-up or API key required to start\!**
  - **Zero-Install Architecture:** Powered by `uvx`. No messy Python environments needed.

-----

## 🚀 Quick Start (Zero Configuration)

You DO NOT need an API key to start. The system will automatically use the built-in trial token.

### For Claude Desktop (Recommended)

Open your configuration file:

  * **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
  * **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

Add the following JSON block. That's it\!

```json
{
  "mcpServers": {
    "nooxus-edge": {
      "command": "uvx",
      "args": [
        "nooxus-mcp@latest"
      ]
    }
  }
}
```

*(Restart Claude Desktop. You will see the 🔨 hammer icon indicating Nooxus tools are loaded.)*

### For Cherry Studio / Cursor

Add a new MCP server and simply specify:

  * **Command**: `uvx`
  * **Args**: `nooxus-mcp@latest`

-----

## 🎯 The Playbook: How to trigger the Sourcing Agent

To guarantee the AI uses the verified database and renders the professional UI, always start your prompts with our cheat code: **` Use Nooxus |  `**

Copy and paste these exact prompts to test the power of Nooxus:

**1. Market Scanning & Discovery**

> *"Use Nooxus | I am looking for verified suppliers of 'terminal testing equipment' or 'communication hardware' in Nanjing. Please search your network and guide me."*

**2. The Deep-Dive Forensic Audit (Killer Feature 🔥)**
*(Once you get a NOO-ID from the search above, run this to expose their true capabilities)*

> *"Use Nooxus | Give me a deep-dive forensic audit on this node: NOO-PFJ77WGLNYHRXDZE. Show me the red flags or trust scores, and offer to draft an RFQ."*

-----

## 🔍 Available AI Tools (Under the hood)

1.  **`semantic_search_nooxus(query)`** Lightning-fast semantic search optimized for manufacturing entities. Returns a list of potential partners and their NOO-IDs.
2.  **`get_nooxus_node(noo_id)`** Retrieves the full, unadulterated verification profile using a `NOO-ID`. Triggers Strategy D to force the AI to act as a Risk Analyst and render a visual warning dashboard.

-----

## 🔑 Advanced: Upgrading your Quota

Once you exhaust the generous daily limits of the global trial key, you can seamlessly plug in your own developer API key for unlimited deep-dive audits.

1.  Register for free at [https://www.google.com/url?sa=E\&source=gmail\&q=SmartGSC.com / Nooxus.com].
2.  Generate your `NOOXUS_API_KEY`.
3.  Update your MCP config by adding the `env` block:

<!-- end list -->

```json
{
  "mcpServers": {
    "nooxus-edge": {
      "command": "uvx",
      "args": ["nooxus-mcp@latest"],
      "env": {
        "NOOXUS_API_KEY": "your_personal_key_here"
      }
    }
  }
}
```

-----

**Official Portal:** [SmartGSC.com](https://smartgsc.com) | **Protocol Details:** [Nooxus.com](https://nooxus.com)
